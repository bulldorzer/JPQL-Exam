package com.korea.shop.service;

import com.korea.shop.batch.OrderStatusScheduler;
import com.korea.shop.domain.Order;
import com.korea.shop.domain.OrderStatus;
import com.korea.shop.repository.OrderRepositoryClass;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class) // JUnit5 버전으로 테스트
@SpringBootTest
@Transactional
public class OrderStatusSchedulerTest {

    @Autowired
    private OrderRepositoryClass orderRepository;

    @Autowired
    private OrderStatusScheduler orderStatusScheduler;

    @Test
    void testCancelUnpaidOrders() {
        // Given: 테스트용 주문 생성 및 저장
        LocalDateTime now = LocalDateTime.now();
        Order order1 = new Order();
        order1.setStatus(OrderStatus.PENDING);
        order1.setOrderDate(now.minusDays(2));
        orderRepository.save(order1);

        Order order2 = new Order();
        order2.setStatus(OrderStatus.PENDING);
        order2.setOrderDate(now.minusDays(3));
        orderRepository.save(order2);

        // When: 배치 스케줄러 실행
        orderStatusScheduler.cancelUnpaidOrders();

        // Then: 주문 상태가 CANCEL로 변경되었는지 확인
        List<Order> canceledOrders = orderRepository.findByStatusAndBeforeDate(OrderStatus.PENDING, now.minusDays(1));
        assertTrue(canceledOrders.isEmpty(), "미결제 주문이 모두 취소되지 않았음");
    }


}
