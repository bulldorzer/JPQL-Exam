package com.korea.shop.domain;

public enum OrderStatus {
    PENDING, ORDER, CANCEL // [주문, 취소]
}
