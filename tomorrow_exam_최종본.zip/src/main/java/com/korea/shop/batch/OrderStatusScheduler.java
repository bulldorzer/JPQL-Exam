package com.korea.shop.batch;

import com.korea.shop.domain.Order;
import com.korea.shop.repository.OrderRepositoryClass;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class OrderStatusScheduler {
    private final OrderRepositoryClass orderRepository;

    @Scheduled(cron = "0 0 0 * * ?")
    @Transactional
    public void cancelUnpaidOrders(){
        log.info("[배치 작업 시작] 미결제 주문 취소 배치 실행");

        LocalDateTime now = LocalDateTime.now();
        List<Order> pendingOrders = orderRepository.findAllByFetch();
        for(Order order : pendingOrders){
            order.cancel();
            log.info("주문 id : {} 취소 완료", order.getId());
        }
        log.info("[배치 작업 완료] 미결제 주문 취소 배치 종료");
    }

}














