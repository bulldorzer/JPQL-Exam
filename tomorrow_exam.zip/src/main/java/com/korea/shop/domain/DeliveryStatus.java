package com.korea.shop.domain;

public enum DeliveryStatus {
    READY, COMP // [준비, 배송]
}
